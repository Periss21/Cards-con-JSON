const personajes_json = fetch('https://rickandmortyapi.com/api/character') 
.then (response => response.json())
.then (personajes_ => {console.log(personajes_)

console.log(typeof(personajes_))


let personajes_results = personajes_.results;
let datos_a_pintar = personajes_results;
pintarDatos(datos_a_pintar);

//Filtros
//Usado: https://www.w3schools.com/jsref/jsref_filter.asp

const boton_filtro_masculino = document.getElementById("masculino");
const boton_filtro_femenino = document.getElementById("femenino");
const boton_eliminar_genero = document.getElementById("eliminar-genero");

//Filtro masculino
boton_filtro_masculino.addEventListener("click", (e)=>{
    e.preventDefault();

    const filtrado_hombre = personajes_.results.filter((checkMale) => checkMale.gender == "Male")

    datos_a_pintar = filtrado_hombre;
    boton_filtro_masculino.classList.add("activo");
    boton_filtro_femenino.classList.remove("activo")
    pintarDatos(datos_a_pintar);
    })


//Filtro femenino
boton_filtro_femenino.addEventListener("click", (e)=>{
    e.preventDefault();
    
    const filtrado_mujer = personajes_.results.filter((checkFemale) => checkFemale.gender == "Female")
    
    datos_a_pintar = filtrado_mujer;
    boton_filtro_femenino.classList.add("activo");
    boton_filtro_masculino.classList.remove("activo")
    pintarDatos(datos_a_pintar);
    })


//Eliminar filtro de genero
boton_eliminar_genero.addEventListener("click", (e)=>{
    e.preventDefault();

    datos_a_pintar = personajes_results;
    boton_filtro_femenino.classList.remove("activo");
    boton_filtro_masculino.classList.remove("activo")
    pintarDatos(datos_a_pintar);
    })

    

//Selección del container en el DOM y creación de bucle en relación a la cantidad de personajes en el api
function pintarDatos (datos_a_pintar) {
let personajes_container = document.getElementById("personajes-container");
    let p_container = '<div class="container">';
    //for (let i = 0; i < 20; i++) {
        //let personajes = personajes_.results[i];
       // let ubicacion = personajes_.location[i];
        //let apariciones = personajes_.episode[i];
        datos_a_pintar.forEach(element => {
        

        //Extraer el número de capítulo para una presentación más limpia
        //Usado: https://www.w3schools.com/js/js_string_methods.asp
        primer_capitulo = element.episode[0];
        numero_cap_final = primer_capitulo.slice(40);



//Estructura de las cards
p_container += `<div class="personajes-card">
            <picture>
                <img class="imagen-personajes" src= ${(element.image)} alt=" element.name ">
            </picture> 

        <div class="categoria">
        <h4> Información básica </h4>
        </div>
        
        <div class="informaciont1">
            <h4> Nombre: ${(element.name)} </h4>
        </div>

        <div class="informaciont1">
            <h4> Estatus: ${(element.status)} </h4>
        </div>

        <div class="informaciont1">
            <h4> Especie: ${(element.species)} </h4>
        </div>
        
        <div class="informaciont1">
            <h4> Tipo: ${(element.type)} </h4>
        </div>

        <div class="informaciont1-2">
            <h4> Género: ${(element.gender)} </h4>
        </div>

        <div class="informaciont1-2">
            <h4> Ubicación: ${(element.location.name)} </h4>
        </div>

        
        <div class="categoria">
        <h4> Primera aparición </h4>
        </div>
        
        <div class="informaciont1_final">
            <h4> Episodio ${numero_cap_final} </h4>
        </div>

        </div>`
            
    })

    personajes_container.innerHTML = p_container;
}})

.catch(err => console.error("ERROR"))